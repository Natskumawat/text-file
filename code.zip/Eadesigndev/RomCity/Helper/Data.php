<?php

namespace Eadesigndev\RomCity\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\CountryFactory;

class Data extends AbstractHelper
{
    const NAME_FILE  = 'ea_romcity/custom_group/city_file_upload';

    /** @var ScopeConfigInterface  */
    public $scopeConfig;

    /** @var StoreManagerInterface  */
    public $storeManager;
    protected $addressRepositoryInterface;

    protected $_customerFactory;
    protected $_addressFactory;
    protected $customer;
    protected $_countryFactory;
    /**
     * Data constructor.
     * @param Context $context
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Customer\Model\AddressFactory $addressFactory,
        \Magento\Customer\Model\Session $customer,
        \Magento\Customer\Model\Address\Config $addressConfig,
        \Magento\Customer\Model\Address\Mapper $addressMapper,
        \Magento\Customer\Api\AddressRepositoryInterface $addressRepositoryInterface,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        CountryFactory $countryFactory,
    ) {
        $this->scopeConfig = $context->getScopeConfig();
        $this->storeManager = $storeManager;
        $this->_customerFactory = $customerFactory;
        $this->_addressFactory = $addressFactory;
        $this->customer = $customer;
        $this->_addressConfig = $addressConfig;
        $this->addressMapper = $addressMapper;
        $this->addressRepositoryInterface = $addressRepositoryInterface;
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->_countryFactory = $countryFactory;
        parent::__construct($context);
    }

    /**
     * @param string $configPath
     * @return bool
     */
    public function getScopeConfig($configPath)
    {
        return $this->scopeConfig->getValue(
            $configPath,
            ScopeInterface::SCOPE_STORE
        );
    }

    public function getConfigFileName($nameFile = self::NAME_FILE)
    {
        return $this->getScopeConfig($nameFile);
    }
    public function getDefaultBillingAdd()
    {
        
        //get customer model before you can get its address data
        $customer = $this->_customerFactory->create()->load($this->customer->getId());    //insert customer id
        $billingAddressId = $customer->getDefaultBilling();
        if(!empty($billingAddressId)){
            $billingAddress = $this->_addressFactory->create()->load($billingAddressId);
            return $billingAddress;
        }
        else{
            return false;
        }
        
    }
    public function getCountryById($countryId)
    {
        return $this->_countryFactory->create()->loadByCode($countryId)->getName();
    }
    // public function _getAddressHtml($address)
    // {
    //     $renderer = $this->_addressConfig->getFormatByCode('html')->getRenderer();
    //     return $renderer->renderArray($this->addressMapper->toFlatArray($address));
    // }
    // public function getAddressObject($sellerBillingAddressId)
    // {
    //     $addressObject = $this->addressRepositoryInterface->getById($this->getAddressId());
    //     return $addressObject;
    // }
    // public function getAddressId()
    // {
    //     $seller = $this->customerRepositoryInterface->getById($this->customer->getId());
    //     $sellerBillingAddressId = $seller->getDefaultBilling();
    //     return $sellerBillingAddressId;
    // }
}
