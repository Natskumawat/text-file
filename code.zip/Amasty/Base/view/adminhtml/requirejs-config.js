var config = {
    config: {
        mixins: {
            'js/theme': {
                'Amasty_Base/js/theme': true
            }
        }
    }
};
