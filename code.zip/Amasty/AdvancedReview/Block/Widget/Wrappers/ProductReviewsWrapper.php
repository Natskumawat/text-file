<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2021 Amasty (https://www.amasty.com)
 * @package Amasty_AdvancedReview
 */


namespace Amasty\AdvancedReview\Block\Widget\Wrappers;

class ProductReviewsWrapper extends \Amasty\AdvancedReview\Block\Widget\Wrapper
{

}
