<?php

namespace Conceptive\Commerce\Plugin;

class RedirectCustomUrl
{
    public $blockObj;
    public $smMega;

    public function __construct(
        \Conceptive\Commerce\Block\Index $blockObj,
        \Sm\MegaMenu\Block\MegaMenu\View $smMega
    ) {
        $this->blockObj = $blockObj;
        $this->smMega = $smMega;
    }
    public function afterExecute(
        \Magento\Customer\Controller\Account\LoginPost $subject,
        $result)
    {
        $customUrl = $this->blockObj->getBaseUrl();
        $items = $this->smMega->getBaseItems();
        // $baseMenuId = $this->smMega->getBaseMenuId();
        $baseMenuId = (isset($_COOKIE['basemenuid']))? $_COOKIE['basemenuid']:'';
        foreach ($items as $item){
            if(($item['items_id'] == $baseMenuId) && (!empty($baseMenuId))){
                if ($item['title'] == "Women") {
                    $customUrl = $customUrl . "categories/women.html";
                } elseif ($item['title'] == "Men") {
                    $customUrl = $customUrl . "categories/men.html";
                } elseif ($item['title'] == "KIDS") {
                    $customUrl = $customUrl . "categories/kids.html";
                }
            }
        }
        $result->setPath($customUrl);
        return $result;
    }

}