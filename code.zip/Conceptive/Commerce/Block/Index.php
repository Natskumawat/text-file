<?php

namespace Conceptive\Commerce\Block;

use Magento\Framework\View\Element\Template;
use Magento\Backend\Block\Template\Context;

class Index extends Template
{
    public $_storeInterface;

    public $_productCollectionFactory;

    public $_customerSession;

    public $imageHelper;

    public $categoryRepository;

    protected $_productRepositoryFactory;

    public function __construct(
        Context $context,
        \Magento\Store\Model\StoreManagerInterface $_storeInterface,
        \Magento\Customer\Model\Session $_customerSession,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        \Magento\Framework\Registry $registry,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Catalog\Helper\Image $imageHelper,
        \Magento\Catalog\Api\ProductRepositoryInterfaceFactory $productRepositoryFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory 
        $_productCollectionFactory,
        array $data = [])
    {
        $this->_storeInterface = $_storeInterface;
        $this->_customerSession = $_customerSession;
        $this->categoryRepository = $categoryRepository;
        $this->_coreRegistry = $registry;
        $this->storeManager = $storeManager;
        $this->imageHelper = $imageHelper;
        $this->_productRepositoryFactory = $productRepositoryFactory;
        $this->_productCollectionFactory= $_productCollectionFactory;
        parent::__construct($context, $data);
    }

    public function getCurrentCategory()
    {
        if (!$this->hasData('current_category')) {
            $this->setData('current_category', $this->_coreRegistry->registry('current_category'));
        }
        return $this->getData('current_category');
    }
    public function getCategoryById($categoryId)
    {
        try{
           
            $category = $this->categoryRepository->get($categoryId);
            return $category;
           
        } catch(\Exception $e){
            // 
        }
    }
     /**
     * get product by id
     *
     * @param [type] $id
     * @return array
     */
    public function getProductById($id)
    {
        return $this->_productRepositoryFactory->create()->getById($id);
    }
    public function getImage($id)
    {
        $productDetail = $this->_productRepositoryFactory->create()->getById($id);
        $image_url = $this->imageHelper->init($productDetail, 'product_page_image_small')->setImageFile($productDetail->getFile())->resize(200)->getUrl();
        return $image_url;
    }

    public function checkIfIsSubcategory($category)
    {
        $store = $this->storeManager->getStore()->getId();
        $store = $this->storeManager->getStore($store);
        $rootId = $store->getRootCategoryId();
        $categoryId = $category->getId();
        // for showing on the every parent category
        // if($categoryId != null && $rootId != $category->getParentId()){
        //     return true;
        // }
        $parentCategory = array(92,93,53);
        if($categoryId != null && in_array($category->getParentId(),$parentCategory)){
            return true;
        }else{
            return false;
        }
    }

    public function getProductCollection($categoryId){
        $collection = $this->_productCollectionFactory->create();
        $collection->addAttributeToSelect('*');
        $collection->addCategoriesFilter(['in' => $categoryId]);
        $collection->setPageSize(1);
        return $collection;
    }
}